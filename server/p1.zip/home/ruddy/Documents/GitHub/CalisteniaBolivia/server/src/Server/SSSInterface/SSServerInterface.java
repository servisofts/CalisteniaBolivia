package Server.SSSInterface;

public interface SSServerInterface {
    public void Start(int puerto);
    public void printLog(String mensaje);

}
